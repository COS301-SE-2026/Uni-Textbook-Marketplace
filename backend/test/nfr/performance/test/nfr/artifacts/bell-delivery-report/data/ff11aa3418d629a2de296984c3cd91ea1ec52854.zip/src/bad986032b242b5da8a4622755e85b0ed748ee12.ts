import { test, expect, request as playwrightRequest } from '@playwright/test';


const FRONTEND_URL = (process.env.FRONTEND_URL ?? 'http://localhost:3000').replace(/\/+$/, '');
const API_URL = (process.env.API_URL ?? 'http://localhost:3001/api').replace(/\/+$/, '');


const DELIVERY_THRESHOLD_MS = Number(process.env.BELL_THRESHOLD_MS ?? 2000);


const SELLER = {
  email: process.env.SELLER_EMAIL ?? 'student1@tuks.co.za',
  password: process.env.SELLER_PASSWORD ?? 'Password123',
};
const BUYER = {
  email: process.env.BUYER_EMAIL ?? 'student2@tuks.co.za',
  password: process.env.BUYER_PASSWORD ?? 'Password123',
};

test.describe('NFR: bell icon reflects notification events', () => {
  test('SSE-delivered notification updates the bell within threshold', async ({
    page,
  }) => {
    
    await page.goto(`${FRONTEND_URL}/login`);
    await page.getByLabel(/email/i).fill(SELLER.email);
    await page.getByLabel(/password/i).fill(SELLER.password);
    await page.getByRole('button', { name: /log ?in/i }).click();

    await expect(page).toHaveURL(/dashboard|listings|home|\/(?!login)/, {
      timeout: 10_000,
    });

    
    const bell = page.getByRole('button', { name: /^notifications/i });
    await expect(bell).toBeVisible({ timeout: 5_000 });

    
    await page.waitForTimeout(1500);

    const before = parseUnread(await bell.getAttribute('aria-label'));

    
    const buyerCtx = await playwrightRequest.newContext();
    const loginRes = await buyerCtx.post(`${API_URL}/auth/login`, {
      data: { email: BUYER.email, password: BUYER.password },
    });
    expect(loginRes.status()).toBe(200);

    const listingsRes = await buyerCtx.get(
      `${API_URL}/listings?limit=50&offset=0`,
    );
    expect(listingsRes.status()).toBe(200);
    const listingsBody = await listingsRes.json();
    const listings: Array<{ id: string; seller: { email: string } }> =
      listingsBody.listings ?? listingsBody.data ?? listingsBody;

    
    const sellerListing = listings.find(
      (l) => l.seller?.email === SELLER.email,
    );

    if (!sellerListing) {
      throw new Error(
        `No APPROVED listing found for ${SELLER.email}. ` +
          `Seed or create one before running this NFR test.`,
      );
    }

    
    const t0 = Date.now();
    const convRes = await buyerCtx.post(`${API_URL}/conversations`, {
      data: { listingId: sellerListing.id },
    });
    expect(convRes.status()).toBeLessThan(300);

    
    await expect
      .poll(
        async () => parseUnread(await bell.getAttribute('aria-label')),
        {
          message: 'bell unread count should increment after conversation starts',
          timeout: DELIVERY_THRESHOLD_MS + 3000,
          intervals: [100, 200, 500],
        },
      )
      .toBeGreaterThan(before);

    const elapsed = Date.now() - t0;
    console.log(
      `[NFR] bell update: ${elapsed} ms (threshold ${DELIVERY_THRESHOLD_MS} ms)`,
    );

    
    expect(elapsed).toBeLessThan(DELIVERY_THRESHOLD_MS);

    
    await buyerCtx.dispose();
  });
});

function parseUnread(label: string | null): number {
  if (!label) return 0;
  const m = label.match(/(\d+)\s*unread/i);
  return m ? parseInt(m[1], 10) : 0;
}